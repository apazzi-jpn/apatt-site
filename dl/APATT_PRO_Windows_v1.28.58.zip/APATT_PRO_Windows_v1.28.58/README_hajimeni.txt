APATT PRO for Windows(VST3・64bit)v1.28.58

お買い上げありがとうございます。APAZZIです。

■ 入れ方
1. このzipを右クリック →「すべて展開」
2. 中の「APATT PRO.vst3」フォルダを、フォルダごと次の場所にコピーします
   C:\Program Files\Common Files\VST3
   ・Windowsの設定によっては「APATT PRO」とだけ見えます。いちばん外側のそのフォルダをコピーしてください
     (中のContentsやx86_64-winまで開かなくて大丈夫です)
   ・「管理者の権限が必要です」と出たら「続行」を押してください
   ・VST3フォルダが無い時は、C:\Program Files\Common Filesの中に「VST3」という名前のフォルダを作ってから入れてください
3. DAWを起動して、プラグインを再スキャンします(DAWによっては自動です)

■ ライセンスの登録
DAWでAPATT PROを開くと「ライセンス登録が必要です」の画面が出ます。
ご購入メールの赤い文字を、APATT LICENSEから最後の行まで全部コピーして、
「コピーしたライセンスキーを貼り付け」を押してください。キーはMacとWindowsで同じものが使えます。
(APATT 1Uは無料版なので、キーは要りません)

■ 対応
Windows 10/11(64bit)・VST3に対応したDAW(Cubase・Studio One・FL Studio・Ableton Live・REAPERなど)
Pro Tools(AAX)のWindows版には、まだ対応していません。
☕コーヒーブレイクのしょうぎは、Windowsに入っているMicrosoft Edge WebView2を使います。

■ 困った時
apatt@kurashin.co までメールしてください。DAWの名前と版、Windowsの版を添えてもらえると早いです。

APAZZI(倉持新吾)  apatt@kurashin.co

--------------------------------------------------------------------
APATT PRO for Windows (VST3, 64-bit) v1.28.58

Thank you for your purchase.

How to install
1. Right-click this zip and choose "Extract All".
2. Copy the "APATT PRO.vst3" folder (the whole folder) to
   C:\Program Files\Common Files\VST3
   If Windows asks for administrator permission, click "Continue".
3. Start your DAW and rescan plug-ins.

License
When you open APATT PRO, paste the whole license key from your purchase email
(from "APATT LICENSE" to the last line). The same key works on Mac and Windows.
(APATT 1U is free and needs no key.)

Requirements: Windows 10/11 (64-bit), a VST3 host. AAX for Windows is not available yet.
Support: apatt@kurashin.co
